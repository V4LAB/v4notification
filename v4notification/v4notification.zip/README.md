=== V4 - Notify your users ===
Contributors: V4LAB
Donate link: https://itsvalentin.com/donate/
Tags: notify, notification, WordPress, notify your users 
Requires at least: 3.3
Tested up to: 5.6
Stable tag: 0.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

V4 Notification gives you better user engagement. This plugin combined with the chrome extension notify your users when you post an article.


== Description ==
[V4 Notification](https://itsvalentin.com/v4_notification/) gives you better user engagement. This plugin combined with the chrome extension notify your users when you post an article.

For more information, check out plugin page at [V4 Notification](https://itsvalentin.com/v4_notification/)


= Features include: =

* Chrome extension
* No settings needed


= Get involved =
Source Code At [V4LAB - V4Search Repository](https://github.com/V4LAB/V4Notification).



== Installation ==

1. Install V4Notification either via the WordPress.org plugin directory, or by uploading the files to your server

2. Activate the plugin through the 'Plugins' menu in WordPress

3. That's All


== Changelog ==

= 0.0.1 =
* Done